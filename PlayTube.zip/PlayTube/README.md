# PlayTube

A lightweight, anonymous YouTube client for Android (Kotlin, Material 3, NewPipeExtractor).

- No Google account, no API keys, no tracking
- Package: `com.play.tube`

## Build

```bash
./gradlew assembleDebug      # debug APK -> app/build/outputs/apk/debug/
```

Or push to GitHub: the workflows in `.github/workflows` build the APK automatically.

## License & credits

PlayTube is a modified version of **SparkTube** by [devfahim00](https://github.com/devfahim00/SparkTube),
which is built on [NewPipeExtractor](https://github.com/TeamNewPipe/NewPipeExtractor).
Licensed under the **GNU GPLv3** (see `LICENSE`). Source code of any distributed build must stay available under the same license.

This project is not affiliated with YouTube or Google.
