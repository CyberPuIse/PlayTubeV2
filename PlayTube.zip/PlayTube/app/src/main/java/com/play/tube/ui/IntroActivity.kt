package com.play.tube.ui

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.PagerSnapHelper
import androidx.recyclerview.widget.RecyclerView
import com.play.tube.R
import com.play.tube.util.AppPrefs
import com.play.tube.util.Themes

/** Three swipeable welcome slides shown once, right after the first splash. */
class IntroActivity : AppCompatActivity() {

    private data class Slide(val icon: Int, val title: Int, val text: Int)

    private val slides = listOf(
        Slide(R.drawable.ic_play_arrow, R.string.intro_title_1, R.string.intro_text_1),
        Slide(R.drawable.ic_download, R.string.intro_title_2, R.string.intro_text_2),
        Slide(R.drawable.ic_favorite, R.string.intro_title_3, R.string.intro_text_3)
    )
    private var page = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        Themes.apply(this)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_intro)

        val pager = findViewById<RecyclerView>(R.id.introPager)
        val dots = findViewById<LinearLayout>(R.id.introDots)
        val next = findViewById<TextView>(R.id.introNext)
        val skip = findViewById<TextView>(R.id.introSkip)

        val lm = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        pager.layoutManager = lm
        pager.adapter = object : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
            override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
                val v = LayoutInflater.from(parent.context).inflate(R.layout.item_intro, parent, false)
                v.layoutParams = RecyclerView.LayoutParams(parent.width, ViewGroup.LayoutParams.MATCH_PARENT)
                return object : RecyclerView.ViewHolder(v) {}
            }

            override fun onBindViewHolder(h: RecyclerView.ViewHolder, position: Int) {
                val s = slides[position]
                h.itemView.findViewById<ImageView>(R.id.introIcon).setImageResource(s.icon)
                h.itemView.findViewById<TextView>(R.id.introTitle).setText(s.title)
                h.itemView.findViewById<TextView>(R.id.introText).setText(s.text)
            }

            override fun getItemCount() = slides.size
        }
        val snap = PagerSnapHelper()
        snap.attachToRecyclerView(pager)

        fun render() {
            dots.removeAllViews()
            val d = resources.displayMetrics.density
            slides.indices.forEach { i ->
                val dot = View(this).apply {
                    setBackgroundResource(if (i == page) R.drawable.bg_dot_on else R.drawable.bg_dot_off)
                }
                dots.addView(dot, LinearLayout.LayoutParams(
                    ((if (i == page) 22 else 8) * d).toInt(), (8 * d).toInt()
                ).also { it.marginStart = (4 * d).toInt(); it.marginEnd = (4 * d).toInt() })
            }
            next.setText(if (page == slides.lastIndex) R.string.intro_start else R.string.intro_next)
            skip.visibility = if (page == slides.lastIndex) View.INVISIBLE else View.VISIBLE
        }
        render()

        pager.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrollStateChanged(rv: RecyclerView, newState: Int) {
                if (newState != RecyclerView.SCROLL_STATE_IDLE) return
                val v = snap.findSnapView(lm) ?: return
                val p = lm.getPosition(v)
                if (p != page && p >= 0) { page = p; render() }
            }
        })

        next.setOnClickListener {
            if (page < slides.lastIndex) pager.smoothScrollToPosition(page + 1) else finishIntro()
        }
        skip.setOnClickListener { finishIntro() }
    }

    private fun finishIntro() {
        AppPrefs.introSeen = true
        startActivity(Intent(this, MainActivity::class.java))
        finish()
        @Suppress("DEPRECATION")
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
    }
}
