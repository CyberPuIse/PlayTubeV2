package com.play.tube.ui.menu

import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.util.TypedValue
import android.view.Gravity
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.play.tube.R
import com.play.tube.data.LocalStore
import com.play.tube.data.RecommendEngine
import com.play.tube.databinding.ActivitySettingsPageBinding
import com.play.tube.download.DownloadCenter
import com.play.tube.playback.PlaybackCenter
import com.play.tube.util.AppPrefs
import com.play.tube.util.CrashReporter
import com.play.tube.util.Themes
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * One full settings PAGE per area (general / video / music) — the menu used
 * to cram these into short-lived bottom sheets, now each area gets its own
 * screen with a back arrow, like the official YouTube app's settings.
 */
class SettingsPageActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsPageBinding

    private val pageType: Int by lazy {
        intent.getIntExtra(EXTRA_TYPE, TYPE_GENERAL)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        Themes.apply(this)
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsPageBinding.inflate(layoutInflater)
        setContentView(binding.root)
        com.play.tube.ui.common.MiniBar.attach(this)

        binding.title.text = when (pageType) {
            TYPE_VIDEO -> getString(R.string.menu_video_settings)
            TYPE_MUSIC -> getString(R.string.menu_music_settings)
            else -> getString(R.string.menu_settings)
        }
        binding.backButton.setOnClickListener { finish() }

        render()
    }

    override fun onResume() {
        super.onResume()
        // Theme / accent change while a picker dialog was up (or the app was
        // backgrounded): rebuild the page with fresh colors.
        if (Themes.recreateIfNeeded(this)) return
        render()
    }

    private fun render() {
        val content = binding.content
        content.removeAllViews()
        when (pageType) {
            TYPE_VIDEO -> renderVideo(content)
            TYPE_MUSIC -> renderMusic(content)
            else -> renderGeneral(content)
        }
    }

    // ----- General -----

    private fun renderGeneral(content: LinearLayout) {
        content.addView(sectionLabel(getString(R.string.section_appearance)))
        content.addView(
            menuRow(getString(R.string.settings_theme), themeLabel()) {
                showThemePicker()
            }
        )
        content.addView(
            menuRow(getString(R.string.settings_accent), accentLabel()) {
                showAccentPicker()
            }
        )
        content.addView(
            menuRow(
                getString(R.string.settings_animations),
                if (AppPrefs.animations) getString(R.string.on) else getString(R.string.off)
            ) {
                AppPrefs.animations = !AppPrefs.animations
                render()
            }
        )
        content.addView(sectionLabel(getString(R.string.section_downloads)))
        content.addView(
            menuRow(
                getString(R.string.settings_wifi_only_downloads),
                if (AppPrefs.wifiOnlyDownloads) getString(R.string.on) else getString(R.string.off)
            ) {
                AppPrefs.wifiOnlyDownloads = !AppPrefs.wifiOnlyDownloads
                render()
            }
        )
        // Local crash logs (Firebase-free crash reporting) — see
        // util/CrashReporter.kt. Row shows how many reports are on the device.
        content.addView(sectionLabel(getString(R.string.section_support)))
        content.addView(
            menuRow(getString(R.string.settings_crash_logs), crashLogCountLabel()) {
                showCrashLogsSheet()
            }
        )
        // "Clear data" lives here now — it used to be a stray menu card.
        content.addView(
            menuRow(getString(R.string.menu_clear_data), "") {
                showClearDataSheet()
            }
        )
    }

    // ----- Crash logs (local crash reporting viewer) -----

    /** Value label for the Crash logs row — number of reports on the device. */
    private fun crashLogCountLabel(): String =
        CrashReporter.listLogs(this).size.toString()

    /**
     * Bottom sheet listing every crash report saved on the device. Tap a row
     * to share that log file (e.g. to the developer via Telegram); Share all
     * sends everything at once; Delete all removes the files.
     */
    private fun showCrashLogsSheet() {
        val logs = CrashReporter.listLogs(this)
        val sheet = BottomSheetDialog(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(16), dp(20), dp(28))
        }
        root.addView(
            TextView(this).apply {
                text = getString(R.string.settings_crash_logs)
                textSize = 18f
                setTextColor(getColor(R.color.on_surface))
                setTypeface(null, Typeface.BOLD)
            }
        )
        root.addView(
            TextView(this).apply {
                text = getString(R.string.crash_logs_location_hint)
                textSize = 12f
                setTextColor(getColor(R.color.on_surface_variant))
                setPadding(0, dp(4), 0, dp(2))
            }
        )

        if (logs.isEmpty()) {
            root.addView(
                TextView(this).apply {
                    text = getString(R.string.crash_logs_empty)
                    textSize = 14f
                    setTextColor(getColor(R.color.on_surface_variant))
                    setPadding(dp(4), dp(14), dp(4), dp(6))
                }
            )
        } else {
            // Share-all + Delete-all side by side.
            val actions = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
                ).also { it.topMargin = dp(12) }
            }
            actions.addView(
                crashSheetAction(getString(R.string.crash_logs_share_all)) {
                    shareAllCrashLogs(logs)
                }.apply {
                    layoutParams = LinearLayout.LayoutParams(
                        0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f
                    ).also { it.marginEnd = dp(5) }
                }
            )
            actions.addView(
                crashSheetAction(getString(R.string.crash_logs_delete_all)) {
                    confirmDeleteCrashLogs(logs.size, sheet)
                }.apply {
                    layoutParams = LinearLayout.LayoutParams(
                        0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f
                    ).also { it.marginStart = dp(5) }
                }
            )
            root.addView(actions)

            logs.forEach { log ->
                root.addView(
                    crashLogRow(log) { shareCrashLog(log) }
                )
            }
        }

        val scroll = android.widget.ScrollView(this).apply { addView(root) }
        sheet.setContentView(scroll)
        sheet.behavior.peekHeight = dp(420)
        sheet.show()
    }

    /** One crash log row: file name bold, size + date below. Tap = share. */
    private fun crashLogRow(
        log: CrashReporter.CrashLogFile,
        onClick: () -> Unit
    ): LinearLayout =
        LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            isClickable = true
            isFocusable = true
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = GradientDrawable().apply {
                cornerRadius = dp(12).toFloat()
                setColor(Themes.elevatedColor(this@SettingsPageActivity))
            }
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).also { it.topMargin = dp(10) }
            setOnClickListener { onClick() }
            addView(
                TextView(this@SettingsPageActivity).apply {
                    text = log.displayName
                    textSize = 14f
                    maxLines = 1
                    ellipsize = android.text.TextUtils.TruncateAt.MIDDLE
                    setTextColor(getColor(R.color.on_surface))
                    setTypeface(null, Typeface.BOLD)
                }
            )
            addView(
                TextView(this@SettingsPageActivity).apply {
                    text = crashRowSubtitle(log)
                    textSize = 12f
                    setTextColor(getColor(R.color.on_surface_variant))
                    setPadding(0, dp(2), 0, 0)
                }
            )
        }

    /** Small pill-shaped action button used at the top of the sheet. */
    private fun crashSheetAction(label: String, onClick: () -> Unit): TextView =
        TextView(this).apply {
            text = label
            textSize = 14f
            gravity = Gravity.CENTER
            isClickable = true
            isFocusable = true
            setPadding(dp(10), dp(10), dp(10), dp(10))
            setTextColor(getColor(R.color.on_surface))
            setTypeface(null, Typeface.BOLD)
            background = GradientDrawable().apply {
                cornerRadius = dp(12).toFloat()
                setColor(Themes.elevatedColor(this@SettingsPageActivity))
            }
            setOnClickListener { onClick() }
        }

    private fun crashRowSubtitle(log: CrashReporter.CrashLogFile): String {
        val date = SimpleDateFormat("d MMM yyyy, HH:mm", Locale.getDefault())
            .format(Date(log.timeMs))
        return "${formatLogSize(log.sizeBytes)} • $date"
    }

    private fun formatLogSize(bytes: Long): String = when {
        bytes >= 1024 * 1024 ->
            String.format(Locale.US, "%.1f MB", bytes / (1024.0 * 1024.0))
        bytes >= 1024 ->
            String.format(Locale.US, "%.1f KB", bytes / 1024.0)
        else -> "$bytes B"
    }

    private fun shareCrashLog(log: CrashReporter.CrashLogFile) {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_STREAM, log.uri)
            putExtra(Intent.EXTRA_SUBJECT, log.displayName)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(intent, getString(R.string.crash_log_share)))
    }

    private fun shareAllCrashLogs(logs: List<CrashReporter.CrashLogFile>) {
        val uris = ArrayList<Uri>(logs.map { it.uri })
        val intent = Intent(Intent.ACTION_SEND_MULTIPLE).apply {
            type = "text/plain"
            putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(intent, getString(R.string.crash_logs_share_all)))
    }

    private fun confirmDeleteCrashLogs(count: Int, sheet: BottomSheetDialog) {
        com.play.tube.ui.common.PremiumDialog(this)
            .setTitle(R.string.crash_logs_delete_all)
            .setMessage(R.string.crash_logs_delete_confirm)
            .setPositiveButton(android.R.string.ok) { _, _ ->
                CrashReporter.deleteAllLogs(this)
                Toast.makeText(
                    this,
                    getString(R.string.crash_logs_deleted, count),
                    Toast.LENGTH_SHORT
                ).show()
                sheet.dismiss()
                render()
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    // ----- Clear data (moved here from the menu) -----

    private fun showClearDataSheet() {
        val sheet = BottomSheetDialog(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(16), dp(20), dp(28))
        }
        root.addView(
            TextView(this).apply {
                text = getString(R.string.menu_clear_data)
                textSize = 18f
                setTextColor(getColor(R.color.on_surface))
                setTypeface(null, Typeface.BOLD)
            }
        )

        fun clearRow(label: Int, title: Int, message: Int, done: Int, action: (Context) -> Unit) {
            root.addView(
                LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(14), dp(14), dp(14), dp(14))
                    background = GradientDrawable().apply {
                        cornerRadius = dp(12).toFloat()
                        setColor(Themes.elevatedColor(this@SettingsPageActivity))
                    }
                    layoutParams = LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
                    ).also { it.topMargin = dp(10) }
                    setOnClickListener {
                        confirm(title, message, done, action)
                        sheet.dismiss()
                    }
                    addView(
                        TextView(this@SettingsPageActivity).apply {
                            text = getString(label)
                            textSize = 15f
                            setTextColor(getColor(R.color.on_surface))
                            setTypeface(null, Typeface.BOLD)
                        }
                    )
                }
            )
        }

        clearRow(
            R.string.clear_history, R.string.clear_history, R.string.clear_history_confirm,
            R.string.history_cleared
        ) { LocalStore.clearHistory(it); RecommendEngine.clearPlays(it) }
        clearRow(
            R.string.clear_music_history, R.string.clear_music_history,
            R.string.clear_music_history_confirm, R.string.music_history_cleared
        ) { LocalStore.clearMusicHistory(it) }
        clearRow(
            R.string.clear_search_history, R.string.clear_search_history,
            R.string.clear_search_history_confirm, R.string.search_history_cleared
        ) { RecommendEngine.clearSearches(it) }
        clearRow(
            R.string.clear_favorites, R.string.clear_favorites, R.string.clear_favorites_confirm,
            R.string.favorites_cleared
        ) { LocalStore.clearFavorites(it) }
        clearRow(
            R.string.clear_subscriptions, R.string.clear_subscriptions,
            R.string.clear_subscriptions_confirm, R.string.subscriptions_cleared
        ) { LocalStore.clearSubscriptions(it) }
        clearRow(
            R.string.clear_downloads, R.string.clear_downloads, R.string.clear_downloads_confirm,
            R.string.downloads_cleared
        ) { DownloadCenter.clearAll(it) }
        clearRow(
            R.string.clear_recommendations, R.string.clear_recommendations,
            R.string.clear_recommendations_confirm, R.string.recommendations_cleared
        ) {
            RecommendEngine.clearPlays(it)
            RecommendEngine.clearSearches(it)
        }

        val scroll = android.widget.ScrollView(this).apply { addView(root) }
        sheet.setContentView(scroll)
        sheet.behavior.peekHeight = dp(420)
        sheet.show()
    }

    private fun confirm(
        titleRes: Int,
        messageRes: Int,
        doneRes: Int,
        action: (Context) -> Unit
    ) {
        com.play.tube.ui.common.PremiumDialog(this)
            .setTitle(titleRes)
            .setMessage(messageRes)
            .setPositiveButton(android.R.string.ok) { _, _ ->
                action(this)
                Toast.makeText(this, doneRes, Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    // ----- Video -----

    private fun renderVideo(content: LinearLayout) {
        content.addView(sectionLabel(getString(R.string.section_quality)))
        content.addView(
            menuRow(getString(R.string.settings_default_quality_wifi), wifiQualityLabel()) {
                showDefaultQualityPicker(forWifi = true)
            }
        )
        content.addView(
            menuRow(getString(R.string.settings_default_quality_data), dataQualityLabel()) {
                showDefaultQualityPicker(forWifi = false)
            }
        )
        content.addView(sectionLabel(getString(R.string.section_playback)))
        content.addView(
            menuRow(
                getString(R.string.settings_smart_streaming),
                if (AppPrefs.smartStreaming) getString(R.string.on) else getString(R.string.off)
            ) {
                AppPrefs.smartStreaming = !AppPrefs.smartStreaming
                render()
            }
        )
        content.addView(
            menuRow(
                getString(R.string.settings_autoplay_next_video),
                if (AppPrefs.videoAutoplayNext) getString(R.string.on) else getString(R.string.off)
            ) {
                AppPrefs.videoAutoplayNext = !AppPrefs.videoAutoplayNext
                render()
            }
        )
    }

    // ----- Music -----

    private fun renderMusic(content: LinearLayout) {
        content.addView(sectionLabel(getString(R.string.section_sound)))
        content.addView(
            menuRow(getString(R.string.settings_audio_quality), audioQualityLabel()) {
                showAudioQualityPicker()
            }
        )
        content.addView(sectionLabel(getString(R.string.section_playback)))
        content.addView(
            menuRow(
                getString(R.string.settings_autoplay_next_song),
                if (AppPrefs.musicAutoplayNext) getString(R.string.on) else getString(R.string.off)
            ) {
                AppPrefs.musicAutoplayNext = !AppPrefs.musicAutoplayNext
                PlaybackCenter.applyMusicAutoplay()
                render()
            }
        )
    }

    // ----- Pickers (theme / accent / quality) -----

    private fun themeLabel(): String = when (AppPrefs.theme) {
        AppPrefs.THEME_LIGHT -> getString(R.string.theme_light)
        AppPrefs.THEME_PITCH_BLACK -> getString(R.string.theme_pitch_black)
        AppPrefs.THEME_AUTO -> getString(R.string.theme_auto)
        else -> getString(R.string.theme_dark)
    }

    private fun showThemePicker() {
        val options = listOf(
            AppPrefs.THEME_AUTO to getString(R.string.theme_auto),
            AppPrefs.THEME_DARK to getString(R.string.theme_dark),
            AppPrefs.THEME_LIGHT to getString(R.string.theme_light),
            AppPrefs.THEME_PITCH_BLACK to getString(R.string.theme_pitch_black)
        )
        val current = options.indexOfFirst { it.first == AppPrefs.theme }
        com.play.tube.ui.common.PremiumDialog(this)
            .setTitle(R.string.settings_theme)
            .setSingleChoiceItems(options.map { it.second }.toTypedArray(), current) { dialog, which ->
                Themes.setTheme(options[which].first, this)
                dialog.dismiss()
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun accentLabel(): String = when (AppPrefs.accent) {
        "blue" -> getString(R.string.accent_blue)
        "purple" -> getString(R.string.accent_purple)
        "green" -> getString(R.string.accent_green)
        "orange" -> getString(R.string.accent_orange)
        "pink" -> getString(R.string.accent_pink)
        "teal" -> getString(R.string.accent_teal)
        else -> getString(R.string.accent_red)
    }

    private fun showAccentPicker() {
        val accents = listOf(
            "red" to getString(R.string.accent_red),
            "blue" to getString(R.string.accent_blue),
            "purple" to getString(R.string.accent_purple),
            "green" to getString(R.string.accent_green),
            "orange" to getString(R.string.accent_orange),
            "pink" to getString(R.string.accent_pink),
            "teal" to getString(R.string.accent_teal)
        )
        val current = accents.indexOfFirst { it.first == AppPrefs.accent }
        com.play.tube.ui.common.PremiumDialog(this)
            .setTitle(R.string.settings_accent)
            .setSingleChoiceItems(accents.map { it.second }.toTypedArray(), current) { dialog, which ->
                Themes.setAccent(accents[which].first, this)
                dialog.dismiss()
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun qualityValueLabel(height: Int): String =
        if (height == 0) {
            getString(R.string.quality_auto_short)
        } else {
            "${height}p"
        }

    private fun wifiQualityLabel(): String = qualityValueLabel(AppPrefs.defaultVideoHeightWifi)

    private fun dataQualityLabel(): String = qualityValueLabel(AppPrefs.defaultVideoHeightData)

    /** @param forWifi true = the Wi-Fi default, false = the mobile-data default. */
    private fun showDefaultQualityPicker(forWifi: Boolean) {
        val choices = listOf(0, 2160, 1440, 1080, 720, 480, 360)
        val labels = choices.map {
            if (it == 0) getString(R.string.quality_auto) else "${it}p"
        }.toTypedArray()
        val currentHeight = if (forWifi) AppPrefs.defaultVideoHeightWifi else AppPrefs.defaultVideoHeightData
        val current = choices.indexOfFirst { it == currentHeight }
        com.play.tube.ui.common.PremiumDialog(this)
            .setTitle(
                if (forWifi) R.string.settings_default_quality_wifi
                else R.string.settings_default_quality_data
            )
            .setSingleChoiceItems(labels, if (current >= 0) current else 0) { dialog, which ->
                if (forWifi) {
                    AppPrefs.defaultVideoHeightWifi = choices[which]
                } else {
                    AppPrefs.defaultVideoHeightData = choices[which]
                }
                dialog.dismiss()
                render()
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun audioQualityLabel(): String = when (AppPrefs.musicAudioQuality) {
        AppPrefs.AUDIO_QUALITY_MEDIUM -> getString(R.string.quality_medium)
        AppPrefs.AUDIO_QUALITY_LOW -> getString(R.string.quality_low)
        else -> getString(R.string.quality_high)
    }

    private fun showAudioQualityPicker() {
        val options = listOf(
            AppPrefs.AUDIO_QUALITY_HIGH to getString(R.string.quality_high),
            AppPrefs.AUDIO_QUALITY_MEDIUM to getString(R.string.quality_medium),
            AppPrefs.AUDIO_QUALITY_LOW to getString(R.string.quality_low)
        )
        val current = options.indexOfFirst { it.first == AppPrefs.musicAudioQuality }
        com.play.tube.ui.common.PremiumDialog(this)
            .setTitle(R.string.settings_audio_quality)
            .setSingleChoiceItems(options.map { it.second }.toTypedArray(), current) { dialog, which ->
                AppPrefs.musicAudioQuality = options[which].first
                dialog.dismiss()
                render()
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    // ----- Row builder -----

    /** Small caps section heading above a group of rows. */
    private fun sectionLabel(text: String): TextView = TextView(this).apply {
        this.text = text.uppercase()
        textSize = 12f
        letterSpacing = 0.1f
        setTypeface(null, Typeface.BOLD)
        setTextColor(Themes.accentColor(this@SettingsPageActivity))
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).also { it.topMargin = dp(20); it.marginStart = dp(6); it.bottomMargin = dp(2) }
    }

    private fun iconFor(label: String): Int {
        val map = mapOf(
            getString(R.string.settings_theme) to R.drawable.ic_palette,
            getString(R.string.settings_accent) to R.drawable.ic_tune,
            getString(R.string.settings_animations) to R.drawable.ic_speed,
            getString(R.string.settings_wifi_only_downloads) to R.drawable.ic_wifi_off,
            getString(R.string.settings_crash_logs) to R.drawable.ic_info,
            getString(R.string.menu_clear_data) to R.drawable.ic_delete,
            getString(R.string.settings_default_quality_wifi) to R.drawable.ic_video_cam,
            getString(R.string.settings_default_quality_data) to R.drawable.ic_video_cam,
            getString(R.string.settings_smart_streaming) to R.drawable.ic_speed,
            getString(R.string.settings_autoplay_next_video) to R.drawable.ic_play_arrow,
            getString(R.string.settings_audio_quality) to R.drawable.ic_audiotrack,
            getString(R.string.settings_autoplay_next_song) to R.drawable.ic_skip_next
        )
        return map[label] ?: R.drawable.ic_settings
    }

    /**
     * Premium settings row: accent icon tile, title, value (or a switch for
     * on/off options) and a chevron, inside a soft rounded card with ripple.
     */
    private fun menuRow(mainLabel: String, valueLabel: String, onClick: () -> Unit): LinearLayout {
        val onText = getString(R.string.on)
        val offText = getString(R.string.off)
        val isToggle = valueLabel == onText || valueLabel == offText
        val accent = Themes.accentColor(this)
        val ctx = this
        return LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(13), dp(14), dp(13))
            isClickable = true
            isFocusable = true
            val shape = GradientDrawable().apply {
                cornerRadius = dp(18).toFloat()
                setColor(Themes.elevatedColor(ctx))
            }
            background = android.graphics.drawable.RippleDrawable(
                android.content.res.ColorStateList.valueOf((accent and 0x00FFFFFF) or 0x22000000),
                shape, null
            )
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).also { it.topMargin = dp(8) }
            setOnClickListener {
                com.play.tube.util.Haptics.soft(it)
                onClick()
            }

            addView(
                android.widget.FrameLayout(ctx).apply {
                    background = GradientDrawable().apply {
                        cornerRadius = dp(12).toFloat()
                        setColor((accent and 0x00FFFFFF) or 0x24000000)
                    }
                    addView(
                        android.widget.ImageView(ctx).apply {
                            setImageResource(iconFor(mainLabel))
                            setColorFilter(accent)
                        },
                        android.widget.FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER)
                    )
                },
                LinearLayout.LayoutParams(dp(40), dp(40)).also { it.marginEnd = dp(14) }
            )

            addView(
                LinearLayout(ctx).apply {
                    orientation = LinearLayout.VERTICAL
                    addView(TextView(ctx).apply {
                        text = mainLabel
                        textSize = 15f
                        setTextColor(getColor(R.color.on_surface))
                        setTypeface(null, Typeface.BOLD)
                    })
                    if (!isToggle && valueLabel.isNotBlank()) {
                        addView(TextView(ctx).apply {
                            text = valueLabel
                            textSize = 13f
                            maxLines = 1
                            ellipsize = android.text.TextUtils.TruncateAt.END
                            setTextColor(getColor(R.color.on_surface_variant))
                            setPadding(0, dp(2), 0, 0)
                        })
                    }
                },
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            )

            if (isToggle) {
                addView(
                    androidx.appcompat.widget.SwitchCompat(ctx).apply {
                        isChecked = valueLabel == onText
                        isClickable = false
                        isFocusable = false
                        thumbTintList = android.content.res.ColorStateList(
                            arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                            intArrayOf(accent, 0xFF9AA0A6.toInt())
                        )
                        trackTintList = android.content.res.ColorStateList(
                            arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                            intArrayOf((accent and 0x00FFFFFF) or 0x66000000, 0x33808080)
                        )
                    }
                )
            } else {
                addView(
                    android.widget.ImageView(ctx).apply {
                        setImageResource(R.drawable.ic_chevron_right)
                        setColorFilter(getColor(R.color.on_surface_variant))
                    },
                    LinearLayout.LayoutParams(dp(22), dp(22))
                )
            }
        }
    }

    private fun dp(value: Int): Int = TypedValue.applyDimension(
        TypedValue.COMPLEX_UNIT_DIP, value.toFloat(), resources.displayMetrics
    ).toInt()

    companion object {
        const val TYPE_GENERAL = 0
        const val TYPE_VIDEO = 1
        const val TYPE_MUSIC = 2
        private const val EXTRA_TYPE = "extra_type"

        fun start(context: Context, type: Int) {
            val intent = Intent(context, SettingsPageActivity::class.java).apply {
                putExtra(EXTRA_TYPE, type)
            }
            context.startActivity(intent)
        }
    }
}
