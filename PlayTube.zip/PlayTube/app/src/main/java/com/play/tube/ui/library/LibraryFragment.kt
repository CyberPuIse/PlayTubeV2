package com.play.tube.ui.library

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.MotionEvent
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.core.view.isVisible
import androidx.core.widget.doAfterTextChanged
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.tabs.TabLayout
import com.play.tube.R
import com.play.tube.data.LocalStore
import com.play.tube.databinding.FragmentLibraryBinding
import com.play.tube.data.DownloadFolders
import com.play.tube.download.DownloadCenter
import com.play.tube.playback.PlaybackCenter
import com.play.tube.playback.QueueEntry
import com.play.tube.ui.channel.ChannelActivity
import com.play.tube.ui.common.ChannelRowAdapter
import com.play.tube.ui.common.DownloadAdapter
import com.play.tube.ui.common.PlaylistAdapter
import com.play.tube.ui.common.VideoAdapter
import com.play.tube.ui.common.toEntry
import com.play.tube.ui.common.toUiModel
import com.play.tube.ui.player.PlayerActivity
import com.play.tube.ui.playlist.PlaylistActivity
import com.play.tube.ui.music.AudioDownloadLibrary
import com.play.tube.ui.music.NowPlayingActivity

/**
 * Two modes (see [newInstance]): the bottom-nav Downloads tab, and the Library page
 * (History, Favorites, Subscriptions, Playlists) opened from the Menu.
 * Everything is stored locally on the device.
 */
class LibraryFragment : Fragment() {

    private var _binding: FragmentLibraryBinding? = null
    private val binding get() = _binding!!

    private lateinit var videoAdapter: VideoAdapter
    private lateinit var channelAdapter: ChannelRowAdapter
    private lateinit var downloadAdapter: DownloadAdapter
    private lateinit var playlistAdapter: PlaylistAdapter

    /** true = bottom-nav Downloads tab; false = Library page (history, favorites, ...). */
    private val downloadsOnly: Boolean by lazy { arguments?.getBoolean(ARG_DOWNLOADS_ONLY, false) ?: false }

    /** Logical tab ids in TabLayout order (positions shift once Downloads is removed). */
    private var tabIds: List<Int> = listOf(TAB_HISTORY, TAB_FAVORITES, TAB_SUBSCRIPTIONS, TAB_PLAYLISTS)

    private var tab = TAB_HISTORY

    // Downloads tab: offline search text and the selected folder (null = All).
    private var downloadQuery = ""
    private var selectedFolder: String? = null
    private val uiHandler = Handler(Looper.getMainLooper())
    private val refreshDownloads = object : Runnable {
        override fun run() { if (_binding != null && tab == TAB_DOWNLOADS) { refresh(); uiHandler.postDelayed(this, 1000) } }
    }
    private var downX = 0f
    private var downY = 0f

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentLibraryBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        videoAdapter = VideoAdapter(
            onClick = { model -> PlayerActivity.start(requireContext(), model) },
            onLongClick = { model ->
                if (tab == TAB_HISTORY) {
                    LocalStore.removeFromHistory(requireContext(), model.url)
                    Toast.makeText(requireContext(), R.string.removed_from_history, Toast.LENGTH_SHORT).show()
                } else {
                    LocalStore.toggleFavorite(requireContext(), model.toEntry())
                    Toast.makeText(requireContext(), R.string.removed_from_favorites, Toast.LENGTH_SHORT).show()
                }
                refresh()
                true
            }
        )
        channelAdapter = ChannelRowAdapter(
            onClick = { channel ->
                ChannelActivity.start(requireContext(), channel.url, channel.name)
            },
            onUnsubscribe = { channel ->
                LocalStore.toggleSubscription(requireContext(), channel)
                Toast.makeText(requireContext(), R.string.unsubscribed_toast, Toast.LENGTH_SHORT).show()
                refresh()
            }
        )
        downloadAdapter = DownloadAdapter(
            onClick = { record -> openDownload(record) },
            onLongClick = { record -> showDownloadActions(record) },
            onPause = { record ->
                if (record.status != DownloadCenter.STATUS_PAUSED) AlertDialog.Builder(requireContext())
                    .setMessage(R.string.download_process_limit).setPositiveButton(android.R.string.ok) { _, _ ->
                        DownloadCenter.togglePause(requireContext(), record); refresh()
                    }.setNegativeButton(android.R.string.cancel, null).show()
                else { DownloadCenter.togglePause(requireContext(), record); refresh() }
            }
        )
        playlistAdapter = PlaylistAdapter(
            onClick = { playlist ->
                PlaylistActivity.start(requireContext(), playlist.id)
            },
            onLongClick = { playlist -> confirmDeletePlaylist(playlist) }
        )

        binding.list.layoutManager = LinearLayoutManager(requireContext())
        binding.list.adapter = videoAdapter

        if (downloadsOnly) {
            // Bottom-nav "Downloads": just the downloaded videos, no tab strip.
            tabIds = listOf(TAB_DOWNLOADS)
            tab = TAB_DOWNLOADS
            binding.title.setText(R.string.tab_downloads)
            binding.tabs.isVisible = false
            binding.downloadTools.isVisible = true
            binding.downloadSearch.doAfterTextChanged {
                downloadQuery = it?.toString().orEmpty().trim()
                bindDownloads()
            }
            bindFolderChips()
        } else {
            // Library page (opened from Menu): downloads live in their own tab now.
            binding.tabs.removeTabAt(TAB_DOWNLOADS)
            binding.title.isVisible = false
        }

        binding.tabs.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab) {
                this@LibraryFragment.tab = tabIds.getOrElse(tab.position) { TAB_HISTORY }
                uiHandler.removeCallbacks(refreshDownloads)
                refresh()
                if (this@LibraryFragment.tab == TAB_DOWNLOADS) uiHandler.post(refreshDownloads)
            }

            override fun onTabUnselected(tab: TabLayout.Tab) = Unit
            override fun onTabReselected(tab: TabLayout.Tab) = Unit
        })

        binding.tabs.selectTab(binding.tabs.getTabAt(tabIds.indexOf(tab).coerceAtLeast(0)))
        binding.list.addOnItemTouchListener(object : RecyclerView.SimpleOnItemTouchListener() {
            private var switched = false
            override fun onInterceptTouchEvent(rv: RecyclerView, event: MotionEvent): Boolean {
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> { downX = event.x; downY = event.y; switched = false }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = event.x - downX
                        val dy = event.y - downY
                        val threshold = 56 * resources.displayMetrics.density
                        if (!switched && kotlin.math.abs(dx) > threshold && kotlin.math.abs(dx) > kotlin.math.abs(dy) * 1.4f) {
                            switched = true
                            val direction = if (rv.layoutDirection == View.LAYOUT_DIRECTION_RTL) -1 else 1
                            val current = tabIds.indexOf(this@LibraryFragment.tab).coerceAtLeast(0)
                            val next = (current + (if (dx < 0) direction else -direction)).coerceIn(0, tabIds.lastIndex)
                            binding.tabs.getTabAt(next)?.select()
                            return true
                        }
                    }
                }
                return false
            }
        })
    }

    fun showDownloadsTab() {
        if (_binding == null) return
        binding.tabs.getTabAt(tabIds.indexOf(TAB_DOWNLOADS))?.select()
        refresh()
        uiHandler.removeCallbacks(refreshDownloads)
        uiHandler.post(refreshDownloads)
    }

    override fun onResume() {
        super.onResume()
        refresh()
        uiHandler.removeCallbacks(refreshDownloads)
        if (tab == TAB_DOWNLOADS) uiHandler.post(refreshDownloads)
    }

    override fun onPause() { uiHandler.removeCallbacks(refreshDownloads); super.onPause() }

    override fun onHiddenChanged(hidden: Boolean) {
        super.onHiddenChanged(hidden)
        uiHandler.removeCallbacks(refreshDownloads)
        if (!hidden) {
            refresh()
            if (tab == TAB_DOWNLOADS) uiHandler.post(refreshDownloads)
        }
    }

    private fun refresh() {
        val context = context ?: return
        when (tab) {
            TAB_HISTORY -> bindVideos(LocalStore.history(context), R.string.empty_history)
            TAB_FAVORITES -> bindVideos(LocalStore.videoFavorites(context), R.string.empty_favorites)
            TAB_SUBSCRIPTIONS -> bindChannels()
            TAB_PLAYLISTS -> bindPlaylists()
            else -> bindDownloads()
        }
    }

    private fun bindVideos(entries: List<com.play.tube.data.VideoEntry>, emptyText: Int) {
        binding.list.adapter = videoAdapter
        videoAdapter.submitList(entries.map { it.toUiModel() })
        binding.emptyView.setText(emptyText)
        binding.emptyView.isVisible = entries.isEmpty()
    }

    private fun bindChannels() {
        val context = context ?: return
        val channels = LocalStore.subscriptions(context)
        binding.list.adapter = channelAdapter
        channelAdapter.submitList(channels)
        binding.emptyView.setText(R.string.empty_subscriptions)
        binding.emptyView.isVisible = channels.isEmpty()
    }

    private fun bindDownloads() {
        val context = context ?: return
        DownloadCenter.refreshStatuses(context)
        // Include audio too so every transfer can be paused, resumed and shared here.
        val all = LocalStore.downloads(context)
        val downloads = if (!downloadsOnly) all else all.filter { record ->
            (downloadQuery.isEmpty() ||
                record.title.contains(downloadQuery, ignoreCase = true) ||
                record.uploader.contains(downloadQuery, ignoreCase = true)) &&
                (selectedFolder == null ||
                    DownloadFolders.folderOf(context, record.videoId) == selectedFolder)
        }
        if (binding.list.adapter !== downloadAdapter) binding.list.adapter = downloadAdapter
        downloadAdapter.submitList(downloads) { downloadAdapter.refreshLiveMetrics() }
        binding.emptyView.setText(if (all.isNotEmpty()) R.string.empty_downloads_search else R.string.empty_downloads)
        binding.emptyView.isVisible = downloads.isEmpty()
    }

    // ----- Download folders -----

    /** Rebuilds the "All / folders / + Folder" chip row (only on changes, not every refresh tick). */
    private fun bindFolderChips() {
        val b = _binding ?: return
        val ctx = context ?: return
        val folders = DownloadFolders.folders(ctx)
        if (selectedFolder != null && selectedFolder !in folders) selectedFolder = null
        b.folderRow.removeAllViews()
        val gap = (8 * resources.displayMetrics.density).toInt()

        fun addChip(label: String, checked: Boolean, onClick: () -> Unit, onLong: (() -> Unit)? = null) {
            val chip = com.google.android.material.chip.Chip(ctx).apply {
                text = label
                isCheckable = true
                isChecked = checked
                setOnClickListener { onClick() }
                if (onLong != null) setOnLongClickListener { onLong(); true }
            }
            val lp = android.widget.LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).also { it.marginEnd = gap }
            b.folderRow.addView(chip, lp)
        }

        addChip(getString(R.string.folder_all), selectedFolder == null, onClick = {
            selectedFolder = null
            bindFolderChips()
            bindDownloads()
        })
        folders.forEach { name ->
            addChip(name, selectedFolder == name, onClick = {
                selectedFolder = name
                bindFolderChips()
                bindDownloads()
            }, onLong = { confirmDeleteFolder(name) })
        }
        addChip(getString(R.string.folder_new_chip), false, onClick = { promptNewFolder(null) })
    }

    private fun showDownloadActions(record: com.play.tube.data.DownloadRecord) {
        val items = arrayOf(getString(R.string.folder_move), getString(R.string.download_delete_action))
        AlertDialog.Builder(requireContext())
            .setTitle(record.title)
            .setItems(items) { _, which ->
                if (which == 0) showFolderPicker(record) else confirmDelete(record)
            }
            .show()
    }

    private fun showFolderPicker(record: com.play.tube.data.DownloadRecord) {
        val ctx = requireContext()
        val folders = DownloadFolders.folders(ctx)
        val labels = arrayOf(getString(R.string.folder_none)) + folders.toTypedArray() +
            arrayOf(getString(R.string.folder_new))
        AlertDialog.Builder(ctx)
            .setTitle(R.string.folder_move)
            .setItems(labels) { _, which ->
                when {
                    which == 0 -> {
                        DownloadFolders.assign(ctx, record.videoId, null)
                        bindDownloads()
                    }
                    which == labels.lastIndex -> promptNewFolder(record)
                    else -> {
                        DownloadFolders.assign(ctx, record.videoId, folders[which - 1])
                        bindDownloads()
                    }
                }
            }
            .show()
    }

    /** Asks for a folder name; when [record] is given the download moves into the new folder. */
    private fun promptNewFolder(record: com.play.tube.data.DownloadRecord?) {
        val ctx = requireContext()
        val input = android.widget.EditText(ctx).apply {
            hint = getString(R.string.folder_name_hint)
            inputType = android.text.InputType.TYPE_CLASS_TEXT
            maxLines = 1
            val pad = (20 * resources.displayMetrics.density).toInt()
            setPadding(pad, pad / 2, pad, pad / 2)
        }
        AlertDialog.Builder(ctx)
            .setTitle(R.string.folder_new)
            .setView(input)
            .setPositiveButton(android.R.string.ok) { _, _ ->
                val name = input.text.toString().trim()
                if (DownloadFolders.create(ctx, name)) {
                    if (record != null) DownloadFolders.assign(ctx, record.videoId, name)
                    bindFolderChips()
                    bindDownloads()
                } else {
                    Toast.makeText(ctx, R.string.folder_exists, Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun confirmDeleteFolder(name: String) {
        val ctx = requireContext()
        AlertDialog.Builder(ctx)
            .setMessage(getString(R.string.folder_delete_confirm, name))
            .setPositiveButton(android.R.string.ok) { _, _ ->
                DownloadFolders.delete(ctx, name)
                if (selectedFolder == name) selectedFolder = null
                bindFolderChips()
                bindDownloads()
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun openDownload(record: com.play.tube.data.DownloadRecord) {
        if (record.type != DownloadCenter.TYPE_AUDIO) {
            PlaybackCenter.playDownload(record)
            return
        }
        val playable = AudioDownloadLibrary.playable(listOf(record)).firstOrNull()
        if (playable == null) {
            Toast.makeText(requireContext(), R.string.download_file_missing, Toast.LENGTH_SHORT).show()
            return
        }
        val (audio, path) = playable
        PlaybackCenter.playMusicQueue(
            listOf(QueueEntry(
                url = "file://$path",
                title = audio.title,
                uploader = audio.uploader,
                thumbnailUrl = audio.thumbnailUrl,
                durationSec = 0L,
                isMusic = true
            )),
            0
        )
        NowPlayingActivity.start(requireContext())
    }

    private fun bindPlaylists() {
        val context = context ?: return
        val playlists = LocalStore.playlists(context)
        binding.list.adapter = playlistAdapter
        playlistAdapter.submitList(playlists)
        binding.emptyView.setText(R.string.empty_playlists)
        binding.emptyView.isVisible = playlists.isEmpty()
    }

    private fun confirmDeletePlaylist(playlist: com.play.tube.data.Playlist) {
        AlertDialog.Builder(requireContext())
            .setTitle(R.string.delete_playlist_confirm)
            .setMessage(playlist.name)
            .setPositiveButton(android.R.string.ok) { _, _ ->
                LocalStore.deletePlaylist(requireContext(), playlist.id)
                Toast.makeText(requireContext(), R.string.playlist_deleted, Toast.LENGTH_SHORT).show()
                refresh()
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    private fun confirmDelete(record: com.play.tube.data.DownloadRecord) {
        AlertDialog.Builder(requireContext())
            .setTitle(R.string.download_delete_confirm)
            .setMessage(record.title)
            .setPositiveButton(android.R.string.ok) { _, _ ->
                DownloadCenter.delete(requireContext(), record)
                Toast.makeText(requireContext(), R.string.download_deleted, Toast.LENGTH_SHORT).show()
                refresh()
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    override fun onDestroyView() {
        uiHandler.removeCallbacks(refreshDownloads)
        super.onDestroyView()
        _binding = null
    }

    companion object {
        private const val ARG_DOWNLOADS_ONLY = "downloads_only"

        fun newInstance(downloadsOnly: Boolean): LibraryFragment = LibraryFragment().apply {
            arguments = Bundle().apply { putBoolean(ARG_DOWNLOADS_ONLY, downloadsOnly) }
        }

        private const val TAB_HISTORY = 0
        private const val TAB_FAVORITES = 1
        private const val TAB_SUBSCRIPTIONS = 2
        private const val TAB_DOWNLOADS = 3
        private const val TAB_PLAYLISTS = 4
    }
}
