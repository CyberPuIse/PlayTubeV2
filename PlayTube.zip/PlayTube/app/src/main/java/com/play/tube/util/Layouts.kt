package com.play.tube.util

import android.content.Context
import android.view.View
import android.animation.ValueAnimator
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView

object Layouts {
    /** 1 column on phones, 2 on small tablets / landscape, 3 on large screens. */
    fun videoSpan(context: Context): Int {
        val w = context.resources.configuration.screenWidthDp
        return when {
            w >= 900 -> 3
            w >= 600 -> 2
            else -> 1
        }
    }
}

/**
 * Collapses [header] in step with the scroll (any speed, even very slow) and
 * brings it back when scrolling up. The list is compensated so the content
 * still follows the finger exactly.
 */
class HeaderHider(private val list: RecyclerView, private val header: View) {
    private var fullHeight = 0
    private var current = -1
    private var compensating = false
    private var snapAnim: ValueAnimator? = null

    init {
        list.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(rv: RecyclerView, dx: Int, dy: Int) {
                if (compensating || dy == 0) return
                if (fullHeight == 0) {
                    fullHeight = header.height
                    if (fullHeight == 0) return
                    current = fullHeight
                }
                snapAnim?.cancel()
                val target = if (!rv.canScrollVertically(-1)) fullHeight
                else (current - dy).coerceIn(0, fullHeight)
                apply(target, compensate = true)
            }

            override fun onScrollStateChanged(rv: RecyclerView, newState: Int) {
                if (newState != RecyclerView.SCROLL_STATE_IDLE || fullHeight == 0) return
                if (current <= 0 || current >= fullHeight) return
                // Settle: finish the collapse / expand instead of leaving it half way.
                val goal = if (current < fullHeight / 2) 0 else fullHeight
                snapAnim = ValueAnimator.ofInt(current, goal).apply {
                    duration = 140
                    addUpdateListener { apply(it.animatedValue as Int, compensate = true) }
                    start()
                }
            }
        })
    }

    private fun apply(h: Int, compensate: Boolean) {
        if (h == current) return
        val delta = h - current
        current = h
        val lp = header.layoutParams
        lp.height = if (h >= fullHeight) ViewGroup.LayoutParams.WRAP_CONTENT else h
        header.layoutParams = lp
        header.alpha = if (fullHeight > 0) (h.toFloat() / fullHeight).coerceIn(0f, 1f) else 1f
        if (compensate && list.canScrollVertically(-1)) {
            compensating = true
            list.scrollBy(0, delta)
            compensating = false
        }
    }
}
