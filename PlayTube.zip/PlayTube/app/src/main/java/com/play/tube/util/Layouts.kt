package com.play.tube.util

import android.content.Context
import android.view.View
import android.animation.ValueAnimator
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView

object Layouts {
    /** 1 column on phones, 2 on small tablets / landscape, 3 on large screens. */
    fun videoSpan(context: Context): Int {
        val w = context.resources.configuration.screenWidthDp
        return when {
            w >= 900 -> 3
            w >= 600 -> 2
            else -> 1
        }
    }
}

/** Collapses [header] while the list scrolls down and brings it back on scroll up. */
class HeaderHider(private val list: RecyclerView, private val header: View) {
    private var fullHeight = 0
    private var hidden = false
    private var anim: ValueAnimator? = null

    init {
        list.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(rv: RecyclerView, dx: Int, dy: Int) {
                if (!rv.canScrollVertically(-1)) { show(); return }
                if (dy > 14) hide() else if (dy < -14) show()
            }
        })
    }

    private fun animateTo(target: Int, endAlpha: Float, wrapAtEnd: Boolean) {
        anim?.cancel()
        val from = header.height
        anim = ValueAnimator.ofInt(from, target).apply {
            duration = 180
            addUpdateListener {
                val lp = header.layoutParams
                lp.height = it.animatedValue as Int
                header.layoutParams = lp
                header.alpha = if (fullHeight > 0) (lp.height.toFloat() / fullHeight).coerceIn(0f, 1f) else endAlpha
            }
            addListener(object : android.animation.AnimatorListenerAdapter() {
                override fun onAnimationEnd(a: android.animation.Animator) {
                    if (wrapAtEnd) {
                        val lp = header.layoutParams
                        lp.height = ViewGroup.LayoutParams.WRAP_CONTENT
                        header.layoutParams = lp
                    }
                }
            })
            start()
        }
    }

    private fun hide() {
        if (hidden) return
        if (fullHeight == 0) fullHeight = header.height
        if (fullHeight == 0) return
        hidden = true
        animateTo(0, 0f, false)
    }

    private fun show() {
        if (!hidden) return
        hidden = false
        animateTo(fullHeight, 1f, true)
    }
}
