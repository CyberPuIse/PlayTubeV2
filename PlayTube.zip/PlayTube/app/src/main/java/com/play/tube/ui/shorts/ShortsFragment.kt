package com.play.tube.ui.shorts

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.media3.ui.PlayerView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.PagerSnapHelper
import androidx.recyclerview.widget.RecyclerView
import com.play.tube.R
import com.play.tube.data.YtRepository
import com.play.tube.databinding.FragmentShortsBinding
import com.play.tube.playback.PlaybackCenter
import com.play.tube.playback.QueueEntry
import com.play.tube.ui.common.toQueueEntry
import com.play.tube.ui.common.toUiModel
import com.play.tube.util.Net
import com.play.tube.util.Thumbs
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import org.schabi.newpipe.extractor.Page

/**
 * Full-screen vertical feed of short clips (≤ [MAX_SECONDS]). One page = one
 * clip; the clip on the settled page plays on loop, tap pauses / resumes.
 */
class ShortsFragment : Fragment() {

    private var _binding: FragmentShortsBinding? = null
    private val binding get() = _binding!!

    private val items = mutableListOf<QueueEntry>()
    private val seen = HashSet<String>()
    private var nextPage: Page? = null
    private var queryIndex = 0
    private var loadJob: Job? = null
    private var exhausted = false

    private var activeHolder: Holder? = null
    private var activePos = -1
    private var startedByShorts = false

    private val adapter = ShortsAdapter()
    private val snap = PagerSnapHelper()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentShortsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.shortsList.layoutManager = LinearLayoutManager(requireContext())
        binding.shortsList.adapter = adapter
        snap.attachToRecyclerView(binding.shortsList)
        binding.shortsList.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrollStateChanged(rv: RecyclerView, newState: Int) {
                if (newState == RecyclerView.SCROLL_STATE_IDLE) playSettledPage()
            }
        })
        if (items.isEmpty()) loadMore() else binding.shortsProgress.isVisible = false
    }

    private fun showEmptyIfNeeded() {
        binding.shortsProgress.isVisible = false
        binding.shortsEmpty.isVisible = items.isEmpty()
    }

    fun onBackOnline() {
        if (_binding != null && items.isEmpty()) loadMore()
    }

    private fun loadMore() {
        if (loadJob?.isActive == true || exhausted) return
        if (!Net.isOnline(requireContext())) {
            showEmptyIfNeeded()
            return
        }
        binding.shortsEmpty.isVisible = false
        if (items.isEmpty()) binding.shortsProgress.isVisible = true
        loadJob = viewLifecycleOwner.lifecycleScope.launch {
            var added = 0
            var rounds = 0
            while (added < MIN_BATCH && rounds < 5) {
                rounds++
                val result = runCatching {
                    YtRepository.searchVideos(QUERIES[queryIndex], nextPage)
                }.getOrNull()
                if (result == null) break
                nextPage = result.nextPage
                result.items.forEach { item ->
                    val model = item.toUiModel()
                    if (model.durationSec in 1..MAX_SECONDS && seen.add(model.url)) {
                        items.add(model.toQueueEntry())
                        added++
                    }
                }
                if (nextPage == null) {
                    if (queryIndex < QUERIES.lastIndex) queryIndex++ else { exhausted = true; break }
                }
            }
            if (_binding == null) return@launch
            val firstLoad = added > 0 && adapter.itemCount == 0
            adapter.notifyDataSetChanged()
            showEmptyIfNeeded()
            if (firstLoad) binding.shortsList.post { playSettledPage() }
        }
    }

    private fun playSettledPage() {
        if (_binding == null || !isVisible || isHidden) return
        val lm = binding.shortsList.layoutManager as? LinearLayoutManager ?: return
        val view = snap.findSnapView(lm) ?: return
        val pos = lm.getPosition(view)
        if (pos == RecyclerView.NO_POSITION || pos == activePos) return
        val holder = binding.shortsList.getChildViewHolder(view) as? Holder ?: return
        playAt(pos, holder)
        if (pos >= items.size - 3) loadMore()
    }

    private fun playAt(pos: Int, holder: Holder) {
        activeHolder?.let { old ->
            old.player.isVisible = false
            PlaybackCenter.detachView(old.player)
        }
        activeHolder = holder
        activePos = pos
        holder.player.isVisible = true
        PlaybackCenter.playVideo(items[pos])
        PlaybackCenter.setVideoLoop(true)
        PlaybackCenter.attachView(holder.player)
        startedByShorts = true
    }

    /** Stops the clip when the tab is left (the mini player must not take it over). */
    private fun stopShorts() {
        if (!startedByShorts) return
        startedByShorts = false
        activeHolder?.let {
            it.player.isVisible = false
            PlaybackCenter.detachView(it.player)
        }
        activeHolder = null
        activePos = -1
        PlaybackCenter.setVideoLoop(false)
        PlaybackCenter.stopPlayback()
    }

    override fun onHiddenChanged(hidden: Boolean) {
        super.onHiddenChanged(hidden)
        if (hidden) stopShorts() else if (_binding != null) {
            binding.shortsList.post { playSettledPage() }
        }
    }

    override fun onStop() {
        super.onStop()
        stopShorts()
    }

    override fun onStart() {
        super.onStart()
        if (_binding != null && !isHidden && items.isNotEmpty()) {
            binding.shortsList.post { playSettledPage() }
        }
    }

    override fun onDestroyView() {
        stopShorts()
        super.onDestroyView()
        _binding = null
    }

    private class Holder(view: View) : RecyclerView.ViewHolder(view) {
        val thumb: ImageView = view.findViewById(R.id.shortThumb)
        val player: PlayerView = view.findViewById(R.id.shortPlayer)
        val title: TextView = view.findViewById(R.id.shortTitle)
        val uploader: TextView = view.findViewById(R.id.shortUploader)
    }

    private inner class ShortsAdapter : RecyclerView.Adapter<Holder>() {
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
            val v = LayoutInflater.from(parent.context).inflate(R.layout.item_short, parent, false)
            v.layoutParams = RecyclerView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, parent.height
            )
            return Holder(v)
        }

        override fun onBindViewHolder(holder: Holder, position: Int) {
            val e = items[position]
            holder.title.text = e.title
            holder.uploader.text = e.uploader
            Thumbs.load(holder.thumb, e.thumbnailUrl)
            holder.player.isVisible = holder === activeHolder
            holder.player.setOnClickListener { PlaybackCenter.togglePlayPause() }
        }

        override fun onViewRecycled(holder: Holder) {
            if (holder === activeHolder) {
                // Page scrolled far away: the surface goes with the view.
                PlaybackCenter.detachView(holder.player)
                activeHolder = null
                activePos = -1
            }
            holder.player.isVisible = false
        }

        override fun getItemCount(): Int = items.size
    }

    private companion object {
        const val MAX_SECONDS = 75L
        const val MIN_BATCH = 8
        val QUERIES = listOf("#shorts", "bangla shorts", "funny shorts", "trending shorts")
    }
}
