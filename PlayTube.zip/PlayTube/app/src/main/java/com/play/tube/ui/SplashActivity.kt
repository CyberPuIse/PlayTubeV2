package com.play.tube.ui

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import androidx.appcompat.app.AppCompatActivity
import com.play.tube.databinding.ActivitySplashBinding
import com.play.tube.util.AppPrefs
import com.play.tube.util.Themes

/**
 * Launcher screen: a short YouTube-style intro (play button pops in with a red
 * glow burst, then the "PlayTube" wordmark slides together) followed by the
 * main screen. The region is fixed to Bangladesh, so there is no region picker.
 */
class SplashActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySplashBinding
    private val handler = Handler(Looper.getMainLooper())
    private var launched = false

    override fun onCreate(savedInstanceState: Bundle?) {
        Themes.apply(this)
        super.onCreate(savedInstanceState)
        binding = ActivitySplashBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Personal build: region is always Bangladesh unless something else was already stored.
        if (AppPrefs.country == null) AppPrefs.country = AppPrefs.DEFAULT_COUNTRY

        if (AppPrefs.animations) {
            playIntro()
            handler.postDelayed({ goNext() }, INTRO_TOTAL_MS)
        } else {
            handler.postDelayed({ goNext() }, 400L)
        }
    }

    private fun playIntro() {
        val b = binding
        val d = resources.displayMetrics.density

        b.logoButton.apply { scaleX = 0f; scaleY = 0f; alpha = 0f; rotation = -14f }
        b.logoPlay.apply { scaleX = 0f; scaleY = 0f }
        b.glow.apply { alpha = 0f; scaleX = 0.3f; scaleY = 0.3f }
        b.wordPlay.apply { alpha = 0f; translationX = -48f * d }
        b.wordTube.apply { alpha = 0f; translationX = 48f * d }
        b.tagline.alpha = 0f

        b.logoButton.animate()
            .scaleX(1f).scaleY(1f).alpha(1f).rotation(0f)
            .setDuration(520)
            .setInterpolator(OvershootInterpolator(1.8f))
            .start()

        b.logoPlay.animate()
            .scaleX(1f).scaleY(1f)
            .setStartDelay(320)
            .setDuration(380)
            .setInterpolator(OvershootInterpolator(2.2f))
            .start()

        // Red glow burst behind the button, then it fades away while expanding.
        b.glow.animate()
            .alpha(1f).scaleX(1.2f).scaleY(1.2f)
            .setStartDelay(380)
            .setDuration(380)
            .withEndAction {
                b.glow.animate()
                    .alpha(0f).scaleX(1.8f).scaleY(1.8f)
                    .setStartDelay(0)
                    .setDuration(450)
                    .start()
            }
            .start()

        b.wordPlay.animate()
            .alpha(1f).translationX(0f)
            .setStartDelay(650)
            .setDuration(420)
            .setInterpolator(DecelerateInterpolator(1.6f))
            .start()
        b.wordTube.animate()
            .alpha(1f).translationX(0f)
            .setStartDelay(650)
            .setDuration(420)
            .setInterpolator(DecelerateInterpolator(1.6f))
            .start()

        b.tagline.animate()
            .alpha(1f)
            .setStartDelay(1000)
            .setDuration(400)
            .start()
    }

    private fun goNext() {
        if (launched || isFinishing || isDestroyed) return
        launched = true
        startActivity(Intent(this, MainActivity::class.java))
        finish()
        @Suppress("DEPRECATION")
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    private companion object {
        const val INTRO_TOTAL_MS = 2000L
    }
}
