package com.play.tube.ui.subscriptions

import android.os.Bundle
import android.os.SystemClock
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.chip.Chip
import com.play.tube.R
import com.play.tube.data.ChannelEntry
import com.play.tube.data.LocalStore
import com.play.tube.data.YtRepository
import com.play.tube.databinding.FragmentSubscriptionsBinding
import com.play.tube.ui.channel.ChannelActivity
import com.play.tube.ui.common.SkeletonAdapter
import com.play.tube.ui.common.VideoAdapter
import com.play.tube.ui.common.showSkeleton
import com.play.tube.ui.common.toUiModel
import com.play.tube.ui.player.PlayerActivity
import com.play.tube.util.Formatters
import com.play.tube.util.Net
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.schabi.newpipe.extractor.stream.StreamInfoItem

/**
 * YouTube-style Subscriptions tab: a row of channel chips on top and, below,
 * the latest videos of the channels you subscribed to (interleaved so every
 * channel shows up). Offline it keeps the skeleton placeholders instead of an error.
 */
class SubscriptionsFragment : Fragment() {

    private var _binding: FragmentSubscriptionsBinding? = null
    private val binding get() = _binding!!

    private lateinit var adapter: VideoAdapter
    private var loadJob: Job? = null
    private var loadedSignature: String? = null
    private var lastLoadedAt = 0L

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentSubscriptionsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        adapter = VideoAdapter(onClick = { model ->
            PlayerActivity.start(requireContext(), model)
        })
        binding.list.layoutManager = LinearLayoutManager(requireContext())
        binding.list.adapter = adapter
        binding.swipe.setOnRefreshListener { load() }
        binding.retryButton.setOnClickListener { load() }
        load()
    }

    override fun onResume() {
        super.onResume()
        refreshIfNeeded()
    }

    override fun onHiddenChanged(hidden: Boolean) {
        super.onHiddenChanged(hidden)
        if (!hidden) refreshIfNeeded()
    }

    /** Called by MainActivity when the connection comes back. */
    fun onBackOnline() {
        if (_binding != null) load()
    }

    private fun refreshIfNeeded() {
        if (_binding == null || !isAdded) return
        val subs = LocalStore.subscriptions(requireContext())
        bindChips(subs)
        val stale = SystemClock.elapsedRealtime() - lastLoadedAt > STALE_MS
        if (signatureOf(subs) != loadedSignature || (stale && adapter.currentList.isEmpty())) load()
    }

    private fun signatureOf(subs: List<ChannelEntry>): String = subs.joinToString("|") { it.url }

    private fun bindChips(subs: List<ChannelEntry>) {
        val b = _binding ?: return
        val ctx = requireContext()
        b.chipRow.removeAllViews()
        b.chipScroll.isVisible = subs.isNotEmpty()
        val gap = (8 * resources.displayMetrics.density).toInt()
        subs.forEach { channel ->
            val chip = Chip(ctx).apply {
                text = channel.name
                isCheckable = false
                setOnClickListener { ChannelActivity.start(ctx, channel.url, channel.name) }
            }
            val lp = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).also { it.marginEnd = gap }
            b.chipRow.addView(chip, lp)
        }
    }

    private suspend fun fetchChannel(url: String): List<StreamInfoItem> =
        try {
            YtRepository.channelVideos(url).first.take(PER_CHANNEL)
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: Exception) {
            emptyList()
        }

    private fun load() {
        val b = _binding ?: return
        val ctx = requireContext()
        val subs = LocalStore.subscriptions(ctx)
        loadedSignature = signatureOf(subs)
        bindChips(subs)
        loadJob?.cancel()
        b.errorView.isVisible = false

        if (subs.isEmpty()) {
            b.list.adapter = adapter
            adapter.submitList(emptyList())
            b.emptyView.isVisible = true
            b.swipe.isRefreshing = false
            return
        }
        b.emptyView.isVisible = false

        loadJob = viewLifecycleOwner.lifecycleScope.launch {
            try {
                if (adapter.currentList.isEmpty()) {
                    showSkeleton(b.list, SkeletonAdapter.STYLE_VIDEO, count = 8)
                }
                if (!Net.isOnline(ctx)) {
                    // Offline: keep the skeleton, MainActivity reloads us when the network is back.
                    lastLoadedAt = 0L
                    return@launch
                }
                val perChannel = withContext(Dispatchers.IO) {
                    subs.take(MAX_CHANNELS).map { channel ->
                        async { fetchChannel(channel.url) }
                    }.awaitAll()
                }
                if (_binding !== b) return@launch
                val merged = ArrayList<StreamInfoItem>()
                for (i in 0 until PER_CHANNEL) {
                    perChannel.forEach { list -> list.getOrNull(i)?.let { merged.add(it) } }
                }
                val models = merged.distinctBy { it.url }.map { it.toUiModel() }
                b.list.adapter = adapter
                adapter.submitList(models)
                lastLoadedAt = SystemClock.elapsedRealtime()
                if (models.isEmpty()) {
                    b.errorText.text = getString(R.string.error_no_results)
                    b.errorView.isVisible = true
                }
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Exception) {
                if (_binding !== b) return@launch
                b.list.adapter = adapter
                if (adapter.currentList.isEmpty()) {
                    b.errorText.text = Formatters.friendlyException(e)
                    b.errorView.isVisible = true
                }
                lastLoadedAt = 0L
            } finally {
                if (_binding === b) b.swipe.isRefreshing = false
            }
        }
    }

    override fun onDestroyView() {
        loadJob?.cancel()
        super.onDestroyView()
        _binding = null
    }

    private companion object {
        const val MAX_CHANNELS = 15
        const val PER_CHANNEL = 4
        const val STALE_MS = 5 * 60 * 1000L
    }
}
